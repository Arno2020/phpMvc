<?php foreach($contact as $indice => $valeur) : ?>
    <div><span><?= $indice ?></span> - <span><?= $valeur ?></span></div>
<?php endforeach; ?>