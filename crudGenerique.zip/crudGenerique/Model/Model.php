<?php
namespace model;

use PDO, PDOException;


class Model
{
    private $db;
    public $table;
    public function __construct(){}

    public function getDB()
    {
        if(!$this->db)
        {
            try{
                $xml = simplexml_load_file('app/config.xml'); 
                // var_dump($xml);
                $this->table = $xml->table;
                try{
                    $this->db = new \PDO(
                        "mysql:dbname=" . $xml->db . ";host=" . $xml->host,
                         $xml->user, 
                         $xml->password, 
                         array(\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION)
                    );
                }
                catch(\PDOException $e){
                    die("Probleme de connexion BDD : " . $e->getMessage());
                }


            }
            catch(Exception $e){
                die('probleme de fichier xml manquant');
            }

        }
        return $this->db;
    }

    public function getFields()
    {
        $q = $this->getDB()->query('DESC ' . $this->table);
        $r = $q->fetchAll(PDO::FETCH_ASSOC);
        return array_slice($r,1); // on retourne tout sauf la colonne id.  
    }

    public function selectAll()
    {
        $q = $this->getDb()->query('SELECT * FROM ' . $this->table);// Je prepare ma requete sql
        $r = $q->fetchAll(PDO::FETCH_ASSOC);// Je demande que le resultat soit sous forme de tableau (FETCH_ASSOC);
        // var_dump($r); die();
        return $r;
    }

    public function select($id)
    {
        $q = $this->getDb()->query('SELECT * FROM ' . $this->table . ' WHERE id_' . $this->table . '= ' . (int) $id);
        $r = $q->fetch(PDO::FETCH_ASSOC); 
        return $r;
    }

    public function save($op)
    { 
        $id = isset($_GET['id']) ? $_GET['id'] : 'NULL';
        $q = $this->getDb()->query('REPLACE INTO ' . $this->table . '(id_' . ($this->table) . ',' .implode(',', array_keys($_POST)) . ') VALUES (' . $id . ',' . "'" . implode("','", $_POST) . "'" . ')');
        var_dump($this); die();        
    }


}